nose plugin for test_steps auto check and log functions
===============================================================

.. image:: https://pypip.in/v/nose_autochecklog/badge.png
    :target: https://crate.io/packages/pytest_autochecklog/

.. image:: https://pypip.in/d/pytest_autochecklog/badge.png
    :target: https://crate.io/packages/pytest_autochecklog/

This nose plugin is very simple, which is for users who use test_steps in nose framework.
Use this plugin, the function detection mechanism is using nose beforeTest to do it, instead of
using the original mechanism, which requires users know more about the auto-function-detection while
writing scripts originally.
Now, it will be all set, while taken care of by this plugin.


Install pytest-autochecklog
---------------------------

::

    pip install pytest-autochecklog




See how to use check functions from test_steps module
------------------------------------------------------

https://pypi.python.org/pypi?:action=display&name=test_steps



