Changelog
=========

v0.1
-------------------------------------------

A simple plugin for py.test. test-steps package is required.

* automatically log test cases and steps
* use py.test mechanism to start log function
